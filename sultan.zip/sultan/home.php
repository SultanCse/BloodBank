<?php
    session_start();
?>



<!DOCTYPE html>
<body>
    
</body>
<h1>Username and password not matched<h1>
        <center><a href="index.html">try again</a><br>
        <a href="index.html">back to home</a></center>
</html> 